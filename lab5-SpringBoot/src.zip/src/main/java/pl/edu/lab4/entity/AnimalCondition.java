package pl.edu.lab4.entity;

public enum AnimalCondition {
    ZDROWE,
    CHORE,
    W_TRAKCIE_ADOPCJI,
    KWARANTANNA
}