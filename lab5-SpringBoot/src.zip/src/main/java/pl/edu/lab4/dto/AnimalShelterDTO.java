package pl.edu.lab4.dto;

public class AnimalShelterDTO {
    private String shelterName;
    private int maxCapacity;

    // Getters and Setters
    public String getShelterName() {
        return shelterName;
    }

    public void setShelterName(String shelterName) {
        this.shelterName = shelterName;
    }

    public int getMaxCapacity() {
        return maxCapacity;
    }

    public void setMaxCapacity(int maxCapacity) {
        this.maxCapacity = maxCapacity;
    }
}
